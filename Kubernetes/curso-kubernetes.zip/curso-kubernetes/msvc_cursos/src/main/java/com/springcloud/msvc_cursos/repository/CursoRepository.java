package com.springcloud.msvc_cursos.repository;

import com.springcloud.msvc_cursos.entity.Curso;
import org.springframework.data.repository.CrudRepository;

public interface CursoRepository extends CrudRepository<Curso, Long> {
}
